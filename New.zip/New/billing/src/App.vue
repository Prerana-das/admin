<template>
    <div id="app">
      <div v-if="!isMainSite">

     
  		   <!--========== ADMIN SIDE MENU one ========-->
      <div class="_1side_menu" v-if="flag==1">
       <div class="_1side_menu_logo">
          <h3 style="text-align:center;">Logo Image</h3>
          <!--<img src="/img/logo.jpg" style="width: 108px;margin-left: 68px;"/>-->
        </div>

          <!--~~~~~~~~ MENU CONTENT ~~~~~~~~-->
        <div class="_1side_menu_content">
          <div class="_1side_menu_img_name">
            <img class="_1side_menu_img" src="/static/pic.png" alt="" title="">

            <p class="_1side_menu_name">Admin</p>
          </div>

            <!--~~~ MENU LIST ~~~~~~-->
        <div class="_1side_menu_list">
          <ul class="_1side_menu_list_ul">
            <li :class="(tab==1)?'_1side_menu_list_ul_active':''" @click="tab=1"><router-link :to="{ name: 'adminNewsOverveiw'}"><Icon type="ios-speedometer" /> Overview </router-link></li>
            
            <li :class="(tab==2)?'_1side_menu_list_ul_active':''" @click="tab=2"><router-link :to="{ name: 'adminMyNews'}"><Icon type="ios-paper-outline" />My News </router-link></li>

            <li :class="(tab==3)?'_1side_menu_list_ul_active':''" @click="tab=3"><router-link :to="{ name: 'adminPostNews'}"><Icon type="md-paper" />  Post News</router-link></li>

            <li :class="(tab==4)?'_1side_menu_list_ul_active':''" @click="tab=4"><router-link :to="{ name: 'adminFeatureNews'}"><Icon type="md-copy" /> Features News </router-link></li>

            <li :class="(tab==5)?'_1side_menu_list_ul_active':''" @click="tab=5"><router-link :to="{ name: 'adminCardNews'}"><Icon type="md-list-box" />Card News</router-link></li>

            <li :class="(tab==6)?'_1side_menu_list_ul_active':''" @click="tab=6"><router-link :to="{ name: 'adminMostViewNews'}"><Icon type="md-eye" />Most View News </router-link></li>

            <li :class="(tab==7)?'_1side_menu_list_ul_active':''" @click="tab=7"><router-link :to="{ name: 'adminNewsCategory'}"><Icon type="md-list" />Category </router-link></li>

          </ul>
        </div>
        </div>
      </div>
        <!--========== ADMIN SIDE MENU ========--> 

         <!--========== USER SIDE MENU two ========-->
      <div class="_1side_menu" v-if="flag==2">
       <div class="_1side_menu_logo">
          <h3 style="text-align:center;">Logo Image</h3>
          <!--<img src="/img/logo.jpg" style="width: 108px;margin-left: 68px;"/>-->
        </div>

          <!--~~~~~~~~ MENU CONTENT ~~~~~~~~-->
        <div class="_1side_menu_content">
          <div class="_1side_menu_img_name">
            <img class="_1side_menu_img" src="/static/pic.png" alt="" title="">

            <p class="_1side_menu_name">David</p>
          </div>

            <!--~~~ MENU LIST ~~~~~~-->
        <div class="_1side_menu_list">
          <ul class="_1side_menu_list_ul">
            <li :class="(tab==1)?'_1side_menu_list_ul_active':''" @click="tab=1"><router-link :to="{ name: 'adminCommunityOverveiw'}"><Icon type="ios-speedometer" /> Overview </router-link></li>
            
            <li :class="(tab==2)?'_1side_menu_list_ul_active':''" @click="tab=2"><router-link :to="{ name: 'adminCommunityCategory'}"><Icon type="md-list" />Category</router-link></li>

            <li :class="(tab==3)?'_1side_menu_list_ul_active':''" @click="tab=2"><router-link :to="{ name: 'adminCommunitySubCategory'}"><Icon type="ios-list" />Subcategory</router-link></li>

               <li :class="(tab==4)?'_1side_menu_list_ul_active':''" @click="tab=2"><router-link :to="{ name: 'adminCommunityTopic'}"><Icon type="ios-copy" />Topic</router-link></li>

            <li :class="(tab==5)?'_1side_menu_list_ul_active':''" @click="tab=3"><router-link :to="{ name: 'adminCommunityReport'}"><Icon type="md-paper" />  Report</router-link></li>

            <li :class="(tab==6)?'_1side_menu_list_ul_active':''" @click="tab=4"><router-link :to="{ name: 'adminCommunityPost'}"><Icon type="md-copy" /> Notice Post </router-link></li>
          </ul>
        </div>

        </div>
      </div>
        <!--========== USER SIDE MENU ========-->

        <!--========== USER SIDE MENU three ========-->
      <div class="_1side_menu" v-if="flag==3">
        <div class="_1side_menu_logo">
          <h3 style="text-align:center;">Logo Image</h3>
          <!--<img src="/img/logo.jpg" style="width: 108px;margin-left: 68px;"/>-->
        </div>

          <!--~~~~~~~~ MENU CONTENT ~~~~~~~~-->
        <div class="_1side_menu_content">
          <div class="_1side_menu_img_name">
            <img class="_1side_menu_img" src="/static/pic.png" alt="" title="">

            <p class="_1side_menu_name">David</p>
          </div>

            <!--~~~ MENU LIST ~~~~~~-->
        <div class="_1side_menu_list">
          <ul class="_1side_menu_list_ul">
            <li :class="(tab==1)?'_1side_menu_list_ul_active':''" @click="tab=1"><router-link :to="{ name: 'dashboard'}"><Icon type="md-document" /> Community</router-link></li>
            <li :class="(tab==2)?'_1side_menu_list_ul_active':''" @click="tab=2"><router-link :to="{ name: 'audit'}"><Icon type="ios-archive" /> Disccusion</router-link></li>
            <li :class="(tab==3)?'_1side_menu_list_ul_active':''" @click="tab=3"><router-link :to="{ name: 'addMoney'}"><Icon type="md-document" /> Community Post </router-link></li>
          </ul>
        </div>
        </div>
      </div>
        <!--========== USER SIDE MENU ========-->

        <!--========== USER SIDE MENU four ========-->
      <div class="_1side_menu" v-if="flag==4">
        <h3>Logo Image</h3>
        <!--<img src="/img/logo.jpg" style="width: 108px;margin-left: 68px;"/>-->
        <div class="_1side_menu_logo">
        
        </div>

          <!--~~~~~~~~ MENU CONTENT ~~~~~~~~-->
        <div class="_1side_menu_content">
          <div class="_1side_menu_img_name">
            <img class="_1side_menu_img" src="/static/pic.png" alt="" title="">

            <p class="_1side_menu_name">David</p>
          </div>

            <!--~~~ MENU LIST ~~~~~~-->
        <div class="_1side_menu_list">
          <ul class="_1side_menu_list_ul">
            <li :class="(tab==1)?'_1side_menu_list_ul_active':''" @click="tab=1"><router-link :to="{ name: 'dashboard'}"><Icon type="md-document" /> Community</router-link></li>
            <li :class="(tab==2)?'_1side_menu_list_ul_active':''" @click="tab=2"><router-link :to="{ name: 'audit'}"><Icon type="ios-archive" /> Disccusion</router-link></li>
            <li :class="(tab==3)?'_1side_menu_list_ul_active':''" @click="tab=3"><router-link :to="{ name: 'addMoney'}"><Icon type="md-document" /> Community Post </router-link></li>
          </ul>
        </div>
        </div>
      </div>
        <!--========== USER SIDE MENU ========-->

         <!--========== USER SIDE MENU five ========-->
      <div class="_1side_menu" v-if="flag==5">
        <h3>Logo Image</h3>
        <!--<img src="/img/logo.jpg" style="width: 108px;margin-left: 68px;"/>-->
        <div class="_1side_menu_logo">
        
        </div>

          <!--~~~~~~~~ MENU CONTENT ~~~~~~~~-->
        <div class="_1side_menu_content">
          <div class="_1side_menu_img_name">
            <img class="_1side_menu_img" src="/static/pic.png" alt="" title="">

            <p class="_1side_menu_name">David</p>
          </div>

            <!--~~~ MENU LIST ~~~~~~-->
        <div class="_1side_menu_list">
          <ul class="_1side_menu_list_ul">
            <li :class="(tab==1)?'_1side_menu_list_ul_active':''" @click="tab=1"><router-link :to="{ name: 'dashboard'}"><Icon type="md-document" /> Community</router-link></li>
            <li :class="(tab==2)?'_1side_menu_list_ul_active':''" @click="tab=2"><router-link :to="{ name: 'audit'}"><Icon type="ios-archive" /> Disccusion</router-link></li>
            <li :class="(tab==3)?'_1side_menu_list_ul_active':''" @click="tab=3"><router-link :to="{ name: 'addMoney'}"><Icon type="md-document" /> Community Post </router-link></li>
          </ul>
        </div>
        </div>
      </div>
        <!--========== USER SIDE MENU ========-->

        <!--========= HEADER ==========-->
      <div class="header">
        <div class="_2menu  _box_shadow">
          <div class="_2menu_logo">
            <ul class="open_button">
              <li ><Icon type="ios-list" /></li>
              <!--<li><Icon type="ios-albums" /></li>-->
            </ul>
          </div>

           <ul class="_2menu_main_ul_list_ul">
              <li @click="flag=1" :class="flag==1?'activeclass':'else class'">
                <p>News</p>
              </li> 
              <li @click="flag=2" :class="flag==2?'activeclass':'else class'">
                <p>Community</p>
              </li>
              <li @click="flag=3" :class="flag==3?'activeclass':'else class'">
                <p>Buy and Sell</p>
              </li> 
              <li @click="flag=4" :class="flag==4?'activeclass':'else class'">
                <p>Real Estate</p>
              </li>
              <li @click="flag=5" :class="flag==5?'activeclass':'else class'">
                <p>Job Search</p>
              </li> 
            </ul>


        </div>
      </div>
            <!--========= HEADER ==========-->
    	<router-view/>
    </div>
    </div>
</template>



<script>
export default {
   data(){
     return {
        flag:1,
       isAdmin: true, 
       tab:1,
       isMainSite: false
     }
   },
   created(){
     
   }
}
</script>
